import DentalLandingPage from "@/components/DentalLandingPage";

export default function Home() {
  return <DentalLandingPage />;
}