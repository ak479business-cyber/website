import ScrollIndicator from '../ScrollIndicator';

export default function ScrollIndicatorExample() {
  return <ScrollIndicator progress={0.65} />;
}