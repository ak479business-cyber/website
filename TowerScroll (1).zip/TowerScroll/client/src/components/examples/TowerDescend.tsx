import TowerDescend from '../TowerDescend';

export default function TowerDescendExample() {
  return <TowerDescend scrollProgress={0.3} />;
}