import TowerReveal from '../TowerReveal';

export default function TowerRevealExample() {
  return <TowerReveal scrollProgress={0.3} />;
}